function setup() {
  createCanvas(800, 400);
  noLoop()
}

function draw() {
  background(220);
  stroke(0)
  noFill()
  drawcircle(200, 200, 200)
  drawRectangle(450, 50, 300, 300)
}
function drawcircle(x, y, radius){
  if(radius < 10)return;
  circle(x, y, radius);
  
  drawcircle(x - radius/2, y, radius/2);
  drawcircle(x + radius/2, y, radius/2);
  drawcircle(x, y - radius/2, radius/2);
  drawcircle(x, y + radius/2, radius/2);
}
function drawRectangle(x, y, w, h){
  if ( w < 5 || h < 5) return;
  rect (x, y, w, h);
  
  drawRectangle( x, y, w/2, h/2);// left up
  drawRectangle( x + w/2, y, w/2, h/2 ); // right up
  drawRectangle(x, y + w/2, w/2, h/2); //left down 
  drawRectangle(x + w/2, y + w/2, w/2, h/2); //right down
}

